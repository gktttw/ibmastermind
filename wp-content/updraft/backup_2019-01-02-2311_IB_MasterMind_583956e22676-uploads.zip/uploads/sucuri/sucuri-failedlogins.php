<?php exit(0); ?>
{"user_login":"TestUser3","attempt_time":1546382957,"remote_addr":"127.0.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko\/20100101 Firefox\/64.0"}
{"user_login":"testuser3","attempt_time":1546382970,"remote_addr":"127.0.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko\/20100101 Firefox\/64.0"}
