<?php
defined( 'ABSPATH' ) or die( 'Cheatin\' uh?' );

$rocket_cookie_hash = 'da7bdb6eca67970ca6325af6357ae53c';
$rocket_cache_mobile_files_tablet = 'desktop';
$rocket_cache_mobile = '1';
$rocket_do_caching_mobile_files = '1';
$rocket_cache_ssl = '1';
$rocket_cache_reject_uri = '/oldone(/(.+/)?feed/?|/(index\.php/)?wp\-json(/.*|$))';
$rocket_cache_reject_cookies = 'wp-postpass_|wptouch_switch_toggle|comment_author_|comment_author_email_';
$rocket_cache_reject_ua = 'facebookexternalhit';
$rocket_cache_query_strings = array (
);
$rocket_secret_cache_key = '5ba1d367ca897215921850';
$rocket_cache_mandatory_cookies = '';
$rocket_cache_dynamic_cookies = array (
);
